#!/bin/bash 
# startup script to setup vnc config used with tightvnc
# run as sudo

# Requirements for VNC server
echo "[*] Installing server requirements ..."
sudo apt-get install gnome-panel gnome-settings-daemon metacity nautilus gnome-terminal

# Install VNC server
 sudo apt install -y tightvncserver

echo "[*] Configuring VNC server ..."
sudo mkdir /etc/vncserver
sudo mv ./vncserver.py /etc/vncserver/vncservers.py
sudo mv ./vncserver.service /etc/systemd/system/vncserver.service

sudo chmod +x /etc/vncserver/vncserver.py
sudo chmod +x /etc/systemd/system/vncserver.service

echo "[*] Initiating VNC Server ..."
sudo su cybergym1 -c "vncserver start :1"
sudo su cybergym1 -c "vncserver -kill :1"

sudo su cybergym2 -c "vncserver start :2"
sudo su cybergym2 -c "vncserver -kill :2"

sudo su cybergym3 -c "vncserver start :3"
sudo su cybergym3 -c "vncserver -kill :3"

sudo su cybergym4 -c "vncserver start :4"
sudo su cybergym4 -c "vncserver -kill :4"

sudo su cybergym5 -c "vncserver start :5"
sudo su cybergym5 -c "vncserver -kill :5"

echo "[*] Setting up xstartup files ..."
sudo cat vnc-xstartup.txt > /home/cybergym1/.vnc/xstartup
sudo cat vnc-xstartup.txt > /home/cybergym2/.vnc/xstartup
sudo cat vnc-xstartup.txt > /home/cybergym3/.vnc/xstartup
sudo cat vnc-xstartup.txt > /home/cybergym4/.vnc/xstartup
sudo cat vnc-xstartup.txt > /home/cybergym5/.vnc/xstartup

echo "[+] Configuration complete ..."
echo "[+] If each user is configured properly: "
echo "[-->] Run sudo systemctl enable vncserver.service && sudo systemctl start vncserver.service"