#!/usr/bin/python3
import os
import sys
import subprocess
from shlex import quote

vncservers = ["1:cybergym1", "2:cybergym2","3:cybergym3","4:cybergym4","5:cybergym5"]

display=''


def start():

    for server in vncservers:
        user = server[2:]
        display = ":{}".format(server[:1]) 
        
        
        try: # Try starting VNC server
            os.system('su {} -c "vncserver -geometry 1024x768 -depth 24 {}"'.format(user, display))
            # os.system(token)
        
        except: # If start fails, stop current connection, then start
            os.system('su {} -c'.format(user), quote("vncserver -kill {}".format(display)))
            # os.system(token)
            
            os.system('su {} -c "vncserver -geometry 1024x768 -depth 24 {}"'.format(user, display))
            # os.system(token)

def stop():
    for server in vncservers:
        user = server[2:]
        display = ":{}".format(server[:1])
        
        os.system('su {} -c'.format(user) + quote("vncserver -kill {}".format(display)))
        # os.system(token)
       

if sys.argv[1] == "start":
    start()
elif sys.argv[1] == "stop":
    stop()
elif sys.argv[1] == "restart":
    stop()
    start()
else:
    print("Correct Syntax is vncserver { start | stop | restart }")

# [ EOF ]
