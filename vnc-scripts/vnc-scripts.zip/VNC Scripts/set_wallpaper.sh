#!/bin/bash
cd /home/abbomberger

sudo cp updated-splash.jpg /home/cybergym1/Downloads/updated_splash.jpg && sudo chown cybergym1 /home/cybergym1/Downloads/updated_splash.jpg
sudo cp updated-splash.jpg /home/cybergym2/Downloads/updated_splash.jpg && sudo chown cybergym2 /home/cybergym2/Downloads/updated_splash.jpg
sudo cp updated-splash.jpg /home/cybergym3/Downloads/updated_splash.jpg && sudo chown cybergym3 /home/cybergym3/Downloads/updated_splash.jpg
sudo cp updated-splash.jpg /home/cybergym4/Downloads/updated_splash.jpg && sudo chown cybergym4 /home/cybergym4/Downloads/updated_splash.jpg
sudo cp updated-splash.jpg /home/cybergym5/Downloads/updated_splash.jpg && sudo chown cybergym5 /home/cybergym5/Downloads/updated_splash.jpg

