#!/bin/bash 
# startup script to setup vnc config used with tightvnc
# run as sudo

# Requirements for VNC server
echo "[+] Installing server requirements ..."
sudo apt-get install gnome-panel gnome-settings-daemon metacity nautilus gnome-terminal

# Install VNC server
 sudo apt install -y tightvncserver

echo "[+] Configuring VNC server ..."
sudo mkdir /etc/vncserver
sudo cp vncservers.conf /etc/vncserver/vncservers.conf

sudo cat Multi_VNC_Script.txt > /etc/init.d/vncserver

sudo chmod +x /etc/init.d/vncserver
echo "[*] Configuration complete ..."
echo 
echo "[!!] Make sure to run command, vncserver, at least once for each user."
echo "[*] To update xstartup files, run: "
echo "su <user>" 
echo "cat vnc-xstartup.txt > ~/.vnc/xstartup"
echo
echo "[*] Run: sudo update-rc.d vncserver defaults 99"
echo "[*] -->  sudo /etc/init.d/vncserver start"