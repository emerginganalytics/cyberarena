# ShinoLocker
Ransomware Simulator
