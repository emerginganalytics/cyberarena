<?php

$file = fopen("password_list.txt", "r") or exit("Unable to open file...");

while(!feof($file))
{
	$password = fgets($file);
	echo md5($password);
}

fclose($file);
?>